# 脑机接口谋杀案 - GitHub Pages 版本

一个基于AI的沉浸式推理游戏，玩家扮演侦探在30分钟内通过与嫌疑人对话找出真凶。

## 🎮 游戏特色

- **AI驱动对话**：与5名嫌疑人进行智能对话
- **线索收集系统**：通过对话解锁和验证线索
- **故事推断引擎**：AI辅助分析线索，生成推理故事
- **成就系统**：5个可解锁成就
- **语音合成**：角色配音（可选）
- **响应式设计**：支持桌面和移动设备

## 🚀 部署说明

### GitHub Pages 部署

1. **上传文件到GitHub仓库**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **启用GitHub Pages**
   - 进入仓库 Settings > Pages
   - Source 选择 "Deploy from a branch"
   - Branch 选择 "main"，文件夹选择 "/docs"
   - 保存设置

3. **访问游戏**
   - 等待部署完成（通常需要几分钟）
   - 访问 `https://你的用户名.github.io/仓库名`

### 本地开发

```bash
# 启动本地服务器
python -m http.server 8000

# 或使用其他静态服务器
npx serve docs
```

## 📁 项目结构

```
docs/
├── index.html          # 主页面
├── css/
│   └── styles.css      # 样式文件
├── js/
│   ├── config.js       # 配置
│   ├── data.js         # 游戏数据
│   ├── game-state.js   # 状态管理
│   ├── api-client.js   # API客户端
│   ├── ui-manager.js   # UI管理
│   ├── game-logic.js   # 游戏逻辑
│   └── main.js         # 主入口
└── assets/
    ├── audio/          # 音频文件
    └── videos/         # 视频文件
```

## ⚙️ 配置说明

### API配置

编辑 `js/config.js` 文件：

```javascript
const CONFIG = {
    // Deepseek API配置
    API_BASE_URL: 'https://api.deepseek.com',
    API_KEY: '你的API密钥',

    // MiniMax TTS配置
    TTS_API_KEY: '你的TTS API密钥',
    // ... 其他配置
};
```

### 获取API密钥

1. **Deepseek API**: 访问 [Deepseek平台](https://platform.deepseek.com)
2. **MiniMax TTS**: 访问 [MiniMax平台](https://api.minimaxi.com)

## 🎯 游戏玩法

1. **开场动画**：观看案件背景介绍
2. **选择嫌疑人**：点击角色按钮开始审讯
3. **智能对话**：与AI角色进行对话，收集线索
4. **线索管理**：查看已收集的线索和证据
5. **故事推断**：使用AI分析线索，生成推理故事
6. **指认凶手**：在30分钟内找出真凶

## 🏆 成就系统

- 🏆 **初次审讯**：完成第一次嫌疑人审讯
- 🔍 **线索猎人**：解锁5条线索
- 🕵️ **真相探索者**：验证10条线索
- ⚡ **速度侦探**：在20分钟内完成调查
- 💬 **对话大师**：与所有嫌疑人进行深入对话

## 📱 技术栈

- **前端**：HTML5, CSS3, JavaScript (ES6+)
- **音频**：Howler.js
- **状态管理**：localStorage
- **API**：Fetch API
- **响应式**：CSS Grid & Flexbox

## 🔧 开发说明

### 添加新角色

1. 在 `js/data.js` 中添加角色数据
2. 配置角色语音ID（在 `js/config.js` 中）
3. 更新UI组件以显示新角色

### 添加新线索

1. 在 `js/data.js` 的 `CLUE_DATABASE` 中添加线索
2. 配置解锁和验证条件
3. 更新角色prompt以包含新线索

### 自定义样式

编辑 `css/styles.css` 文件，修改颜色变量：

```css
:root {
    --primary-bg: #0d1117;
    --accent-primary: #58a6ff;
    /* ... 其他变量 */
}
```

## 📄 许可证

本项目仅供学习和娱乐使用。

## 🤝 贡献

欢迎提交Issue和Pull Request！

---

**魔搭社区特别版** - 优化部署体验，提升推理性能